import BookForm from "./books-form"

const BookNew = () => {
    return (
        <>
            <h1>This is the create form</h1>
            <BookForm data={[]} />
        </>
    )
}

export default BookNew