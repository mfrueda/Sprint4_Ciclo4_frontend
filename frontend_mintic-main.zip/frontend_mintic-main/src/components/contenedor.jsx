const Contenedor = () => {
    return (
        <div className="contenedor-principal">
            <div className="contenedor-imagen">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/640px-Image_created_with_a_mobile_phone.png" alt="imagen" />
            </div>
            <h1>Este es un texto al lado de una imagen</h1>
        </div>

    )
}

export default Contenedor